extern void play(const char *name);
extern void pause(const char *name);   
extern void stop(const char *name);